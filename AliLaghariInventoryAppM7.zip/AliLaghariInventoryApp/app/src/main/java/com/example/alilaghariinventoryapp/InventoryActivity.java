package com.example.alilaghariinventoryapp;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryActivity extends AppCompatActivity {

    private TableLayout inventoryTable;
    private TextView inventoryStatus;
    private EditText searchInput;
    private List<InventoryItem> items = new ArrayList<>();

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    // Hold a snapshot of one database row for display.
    private static class InventoryItem {
        final long id;
        final String name;
        final String sku;
        final int quantity;

        InventoryItem(long id, String name, String sku, int quantity) {
            this.id = id;
            this.name = name;
            this.sku = sku;
            this.quantity = quantity;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.inventoryRoot), (view, windowInsets) -> {
                    Insets insets = windowInsets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                                    | WindowInsetsCompat.Type.ime());
                    view.setPadding(
                            insets.left, insets.top,
                            insets.right, insets.bottom);
                    return windowInsets;
                });

        inventoryTable = findViewById(R.id.inventoryTable);
        inventoryStatus = findViewById(R.id.inventoryStatusText);
        searchInput = findViewById(R.id.searchInventoryInput);

        // Remove the preview row while preserving the table header.
        clearRows();

        findViewById(R.id.addItemButton).setOnClickListener(view ->
                startActivity(new Intent(this, ItemFormActivity.class)));

        findViewById(R.id.smsSettingsButton).setOnClickListener(view ->
                startActivity(new Intent(this, SmsSettingsActivity.class)));

        findViewById(R.id.logoutButton).setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence text, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence text, int start, int before, int count) {
                displayItems();
            }

            @Override
            public void afterTextChanged(Editable text) {
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload after returning from the add/edit screen.
        loadInventory();
    }

    private void loadInventory() {
        inventoryStatus.setText("Loading inventory...");

        databaseExecutor.execute(() -> {
            List<InventoryItem> loadedItems = new ArrayList<>();
            boolean success = true;

            try (DatabaseHelper database = new DatabaseHelper(this);
                 Cursor cursor = database.getAllItems()) {
                while (cursor.moveToNext()) {
                    loadedItems.add(new InventoryItem(
                            cursor.getLong(0),
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getInt(3)));
                }
            } catch (RuntimeException exception) {
                success = false;
                android.util.Log.e(
                        "Inventory", "Inventory loading failed", exception);
            }

            final boolean loaded = success;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                if (loaded) {
                    items = loadedItems;
                    displayItems();
                } else {
                    inventoryStatus.setText(
                            "Unable to load inventory. Reopen this screen to retry.");
                }
            });
        });
    }

    private void clearRows() {
        int rowCount = inventoryTable.getChildCount();
        if (rowCount > 1) {
            inventoryTable.removeViews(1, rowCount - 1);
        }
    }

    private void displayItems() {
        clearRows();

        String query = searchInput.getText().toString()
                .trim().toLowerCase(Locale.ROOT);
        int shown = 0;

        for (InventoryItem item : items) {
            if (item.name.toLowerCase(Locale.ROOT).contains(query)
                    || item.sku.toLowerCase(Locale.ROOT).contains(query)) {
                addInventoryRow(item);
                shown++;
            }
        }

        if (items.isEmpty()) {
            inventoryStatus.setText("No items yet. Tap Add Item to get started.");
        } else if (shown == 0) {
            inventoryStatus.setText("No matching items.");
        } else {
            inventoryStatus.setText("Items shown: " + shown);
        }
    }

    private void addInventoryRow(InventoryItem item) {
        TableRow row = new TableRow(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setBackgroundColor(Color.WHITE);

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setLayoutParams(new TableRow.LayoutParams(
                dp(140), TableRow.LayoutParams.WRAP_CONTENT));

        details.addView(makeText(item.name, 16));
        details.addView(makeText("SKU: " + item.sku, 14));

        if (item.quantity == 0) {
            TextView stockStatus = makeText("Out of stock", 14);
            stockStatus.setTextColor(Color.parseColor("#B3261E"));
            details.addView(stockStatus);
        }
        row.addView(details);

        LinearLayout quantityControls = new LinearLayout(this);
        quantityControls.setGravity(Gravity.CENTER_VERTICAL);
        quantityControls.setLayoutParams(new TableRow.LayoutParams(
                dp(156), TableRow.LayoutParams.WRAP_CONTENT));

        Button decrease = makeButton("−", 48, false);
        decrease.setContentDescription("Decrease " + item.name + " quantity");
        decrease.setEnabled(item.quantity > 0);
        decrease.setOnClickListener(view -> changeQuantity(item, -1));

        TextView quantityText = makeText(String.valueOf(item.quantity), 20);
        quantityText.setGravity(Gravity.CENTER);
        quantityText.setLayoutParams(new LinearLayout.LayoutParams(
                dp(48), LinearLayout.LayoutParams.WRAP_CONTENT));

        Button increase = makeButton("+", 48, false);
        increase.setContentDescription("Increase " + item.name + " quantity");
        increase.setEnabled(item.quantity < Integer.MAX_VALUE);
        increase.setOnClickListener(view -> changeQuantity(item, 1));

        quantityControls.addView(decrease);
        quantityControls.addView(quantityText);
        quantityControls.addView(increase);
        row.addView(quantityControls);

        LinearLayout actions = new LinearLayout(this);
        actions.setLayoutParams(new TableRow.LayoutParams(
                dp(176), TableRow.LayoutParams.WRAP_CONTENT));

        Button edit = makeButton("Edit", 80, false);
        edit.setContentDescription("Edit " + item.name);
        edit.setOnClickListener(view -> {
            Intent intent = new Intent(this, ItemFormActivity.class);
            intent.putExtra("itemId", item.id);
            startActivity(intent);
        });

        Button delete = makeButton("Delete", 88, true);
        delete.setContentDescription("Delete " + item.name);
        delete.setOnClickListener(view ->
                new AlertDialog.Builder(this)
                        .setTitle("Delete " + item.name + "?")
                        .setMessage("This will remove the item from inventory.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete",
                                (dialog, which) -> deleteItem(item.id))
                        .show());

        actions.addView(edit);
        actions.addView(delete);
        row.addView(actions);
        inventoryTable.addView(row);
    }

    private TextView makeText(String text, int size) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(size);
        label.setTextColor(Color.parseColor("#172B4D"));
        return label;
    }

    private Button makeButton(String text, int width, boolean destructive) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setSingleLine(true);
        button.setLayoutParams(new LinearLayout.LayoutParams(dp(width), dp(48)));
        button.setTextColor(Color.parseColor(
                destructive ? "#8C1D18" : "#004D40"));
        button.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(
                destructive ? "#F9DEDC" : "#DCEEEA")));
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void changeQuantity(InventoryItem item, int change) {
        databaseExecutor.execute(() -> {
            boolean updated = false;
            boolean becameOutOfStock = false;
            String itemName = "";
            String itemSku = "";

            try (DatabaseHelper database = new DatabaseHelper(this);
                 Cursor cursor = database.getItem(item.id)) {

                if (cursor.moveToFirst()) {
                    int currentQuantity = cursor.getInt(3);
                    long newQuantity = (long) currentQuantity + change;

                    itemName = cursor.getString(1);
                    itemSku = cursor.getString(2);

                    if (newQuantity >= 0
                            && newQuantity <= Integer.MAX_VALUE) {

                        updated = database.updateItem(
                                item.id, itemName, itemSku,
                                (int) newQuantity);

                        // Alert only when a successful update reduces stock to zero.
                        becameOutOfStock = updated
                                && currentQuantity > 0
                                && newQuantity == 0;
                    }
                }
            } catch (RuntimeException exception) {
                android.util.Log.e(
                        "Inventory", "Quantity update failed", exception);
            }

            finishInventoryChange(updated, "Quantity updated.");

            // Request SMS after the database update has completed.
            if (becameOutOfStock) {
                SmsNotifier.sendOutOfStockAlert(
                        getApplicationContext(), itemName, itemSku);
            }
        });
    }

    private void deleteItem(long itemId) {
        databaseExecutor.execute(() -> {
            boolean deleted = false;

            try (DatabaseHelper database = new DatabaseHelper(this)) {
                deleted = database.deleteItem(itemId);
            } catch (RuntimeException exception) {
                android.util.Log.e(
                        "Inventory", "Item deletion failed", exception);
            }

            finishInventoryChange(deleted, "Item deleted.");
        });
    }

    private void finishInventoryChange(boolean success, String message) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }

            Toast.makeText(this,
                    success ? message : "Unable to change this item.",
                    Toast.LENGTH_SHORT).show();
            loadInventory();
        });
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}