package com.example.alilaghariinventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context.getApplicationContext(),
                DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Store account credentials as a salted password hash.
        db.execSQL(
                "CREATE TABLE users (" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL)"
        );

        // Start with an empty inventory for users to populate.
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "sku TEXT NOT NULL UNIQUE, " +
                        "quantity INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK(quantity >= 0))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Add data-preserving migrations here for future versions.
        // Version 1 does not require a migration.
    }

    // Return the new account ID, or -1 if the username already exists.
    public long createUser(String username, String password) {
        byte[] salt = new byte[16];
        new java.security.SecureRandom().nextBytes(salt);

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put("username", username.trim());
        values.put("password_salt",
                android.util.Base64.encodeToString(
                        salt, android.util.Base64.NO_WRAP));
        values.put("password_hash",
                android.util.Base64.encodeToString(
                        hashPassword(password, salt),
                        android.util.Base64.NO_WRAP));

        return getWritableDatabase().insertWithOnConflict(
                "users", null, values,
                SQLiteDatabase.CONFLICT_IGNORE);
    }

    // Use a parameterized query so input is not treated as SQL code.
    public boolean authenticateUser(String username, String password) {
        try (android.database.Cursor cursor =
                     getReadableDatabase().query(
                             "users",
                             new String[]{"password_hash", "password_salt"},
                             "username = ?",
                             new String[]{username.trim()},
                             null, null, null)) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] storedHash = android.util.Base64.decode(
                    cursor.getString(0), android.util.Base64.NO_WRAP);
            byte[] salt = android.util.Base64.decode(
                    cursor.getString(1), android.util.Base64.NO_WRAP);

            return java.security.MessageDigest.isEqual(
                    storedHash, hashPassword(password, salt));
        }
    }

    // PBKDF2 stores a derived hash instead of the original password.
    private byte[] hashPassword(String password, byte[] salt) {
        javax.crypto.spec.PBEKeySpec specification =
                new javax.crypto.spec.PBEKeySpec(
                        password.toCharArray(), salt, 600000, 256);

        try {
            return javax.crypto.SecretKeyFactory
                    .getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(specification)
                    .getEncoded();
        } catch (java.security.GeneralSecurityException exception) {
            throw new IllegalStateException(
                    "Password hashing is unavailable.", exception);
        } finally {
            specification.clearPassword();
        }
    }
    // Add an inventory item. Return -1 if its SKU already exists.
    public long addItem(String name, String sku, int quantity) {
        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put("name", name.trim());
        values.put("sku", sku.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().insertWithOnConflict(
                "inventory", null, values,
                SQLiteDatabase.CONFLICT_IGNORE);
    }

    // The caller must close the returned cursor after reading it.
    public android.database.Cursor getAllItems() {
        return getReadableDatabase().query(
                "inventory",
                new String[]{"_id", "name", "sku", "quantity"},
                null, null, null, null,
                "name COLLATE NOCASE ASC");
    }

    public android.database.Cursor getItem(long itemId) {
        return getReadableDatabase().query(
                "inventory",
                new String[]{"_id", "name", "sku", "quantity"},
                "_id = ?",
                new String[]{String.valueOf(itemId)},
                null, null, null);
    }

    // Update only the selected item; duplicate SKUs are rejected.
    public boolean updateItem(
            long itemId, String name, String sku, int quantity) {

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put("name", name.trim());
        values.put("sku", sku.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().updateWithOnConflict(
                "inventory", values,
                "_id = ?",
                new String[]{String.valueOf(itemId)},
                SQLiteDatabase.CONFLICT_IGNORE) == 1;
    }

    public boolean deleteItem(long itemId) {
        return getWritableDatabase().delete(
                "inventory",
                "_id = ?",
                new String[]{String.valueOf(itemId)}) == 1;
    }
}