package com.example.alilaghariinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createAccountButton;

    // Keep database access and password hashing off the UI thread.
    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (view, windowInsets) -> {
                    Insets insets = windowInsets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                                    | WindowInsetsCompat.Type.ime());

                    view.setPadding(
                            insets.left, insets.top,
                            insets.right, insets.bottom);
                    return windowInsets;
                });

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(view -> processAccount(false));
        createAccountButton.setOnClickListener(view -> processAccount(true));
    }

    private void processAccount(boolean creatingAccount) {
        if (!validateInputs()) {
            return;
        }

        // Capture input before starting background work.
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        setBusy(true);

        databaseExecutor.execute(() -> {
            boolean success = false;
            String message;

            try (DatabaseHelper database = new DatabaseHelper(this)) {
                if (creatingAccount) {
                    success = database.createUser(username, password) != -1;
                    message = success
                            ? "Account created. You can now log in."
                            : "That username already exists.";
                } else {
                    success = database.authenticateUser(username, password);
                    message = success
                            ? "Login successful."
                            : "Incorrect username or password.";
                }
            } catch (RuntimeException exception) {
                message = "Unable to access the database. Please try again.";
                android.util.Log.e(
                        "AccountDatabase", "Account operation failed",
                        exception);
            }

            final boolean accountSuccess = success;
            final String resultMessage = message;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setBusy(false);
                Toast.makeText(
                        this, resultMessage, Toast.LENGTH_LONG).show();

                if (accountSuccess) {
                    passwordInput.setText("");

                    if (!creatingAccount) {
                        startActivity(
                                new Intent(this, InventoryActivity.class));
                        finish();
                    }
                }
            });
        });
    }

    private boolean validateInputs() {
        usernameInput.setError(null);
        passwordInput.setError(null);

        if (usernameInput.getText().toString().trim().isEmpty()) {
            usernameInput.setError("Enter your username.");
            usernameInput.requestFocus();
            return false;
        }

        if (passwordInput.getText().toString().isEmpty()) {
            passwordInput.setError("Enter your password.");
            passwordInput.requestFocus();
            return false;
        }

        return true;
    }

    private void setBusy(boolean busy) {
        loginButton.setEnabled(!busy);
        createAccountButton.setEnabled(!busy);
        usernameInput.setEnabled(!busy);
        passwordInput.setEnabled(!busy);
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}