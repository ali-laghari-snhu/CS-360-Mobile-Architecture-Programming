package com.example.alilaghariinventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    private TextView permissionStatus;
    private EditText phoneInput;
    private SharedPreferences preferences;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        preferences.edit()
                                .putBoolean("smsEnabled", granted)
                                .apply();

                        updateStatus();

                        if (!granted) {
                            permissionStatus.setText(
                                    "SMS permission was not granted. "
                                            + "You can continue managing inventory "
                                            + "without SMS alerts."
                            );
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_settings);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.smsSettingsRoot),
                (view, windowInsets) -> {
                    Insets insets = windowInsets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                                    | WindowInsetsCompat.Type.ime()
                    );

                    view.setPadding(
                            insets.left,
                            insets.top,
                            insets.right,
                            insets.bottom
                    );

                    return windowInsets;
                }
        );

        permissionStatus = findViewById(R.id.smsPermissionStatus);
        phoneInput = findViewById(R.id.notificationPhoneInput);
        preferences = getSharedPreferences("smsSettings", MODE_PRIVATE);

        phoneInput.setText(preferences.getString("recipientPhone", ""));

        findViewById(R.id.enableSmsButton).setOnClickListener(view -> {
            String phone = phoneInput.getText().toString().trim();

            if (phone.isEmpty()) {
                phoneInput.setError("Enter a recipient phone number.");
                phoneInput.requestFocus();
                return;
            }

            preferences.edit()
                    .putString("recipientPhone", phone)
                    .apply();

            if (hasSmsPermission()) {
                preferences.edit()
                        .putBoolean("smsEnabled", true)
                        .apply();
                updateStatus();
            } else if (shouldShowRequestPermissionRationale(
                    Manifest.permission.SEND_SMS)) {

                new AlertDialog.Builder(this)
                        .setTitle("Allow SMS alerts?")
                        .setMessage(
                                "SMS permission is needed to send stock alerts. "
                                        + "Inventory management still works "
                                        + "if you decline."
                        )
                        .setPositiveButton("Continue", (dialog, which) ->
                                permissionLauncher.launch(
                                        Manifest.permission.SEND_SMS))
                        .setNegativeButton("Not Now", null)
                        .show();
            } else {
                permissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        findViewById(R.id.disableSmsButton).setOnClickListener(view -> {
            preferences.edit()
                    .putBoolean("smsEnabled", false)
                    .apply();
            updateStatus();
        });

        findViewById(R.id.backToInventoryButton)
                .setOnClickListener(view -> finish());

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (permissionStatus != null) {
            updateStatus();
        }
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateStatus() {
        boolean enabled = preferences.getBoolean("smsEnabled", false);

        if (hasSmsPermission() && enabled) {
            permissionStatus.setText(
                    "SMS permission granted. Stock alerts are selected."
            );
        } else if (hasSmsPermission()) {
            permissionStatus.setText(
                    "SMS alerts are off. You can enable them at any time."
            );
        } else {
            permissionStatus.setText(
                    "SMS alerts are off. Permission has not been granted. "
                            + "Inventory management remains available."
            );
        }
    }
}