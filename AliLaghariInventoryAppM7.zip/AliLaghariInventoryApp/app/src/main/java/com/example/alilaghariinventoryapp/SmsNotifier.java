package com.example.alilaghariinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public final class SmsNotifier {

    private SmsNotifier() {
        // Utility class: no instance is needed.
    }

    @SuppressWarnings("deprecation")
    public static void sendOutOfStockAlert(
            Context context, String itemName, String sku) {

        Context appContext = context.getApplicationContext();

        SharedPreferences preferences =
                appContext.getSharedPreferences(
                        "smsSettings", Context.MODE_PRIVATE);

        // Inventory remains usable when alerts are disabled or denied.
        if (!preferences.getBoolean("smsEnabled", false)) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                appContext, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String phoneNumber =
                preferences.getString("recipientPhone", "").trim();

        if (phoneNumber.isEmpty()) {
            showMessage(appContext,
                    "SMS alert skipped: set a recipient number.");
            return;
        }

        try {
            TelephonyManager telephonyManager =
                    appContext.getSystemService(TelephonyManager.class);

            boolean supportsSms = appContext.getPackageManager()
                    .hasSystemFeature(
                            PackageManager.FEATURE_TELEPHONY_MESSAGING);

            // Compatibility fallback for SMS-capable devices.
            if (!supportsSms && telephonyManager != null) {
                supportsSms = telephonyManager.isSmsCapable();
            }

            if (!supportsSms) {
                showMessage(appContext,
                        "SMS is unavailable on this device.");
                return;
            }

            SmsManager smsManager =
                    appContext.getSystemService(SmsManager.class);

            if (smsManager == null) {
                showMessage(appContext, "SMS service is unavailable.");
                return;
            }

            String message = "Stockroom alert: "
                    + itemName + " (SKU: " + sku
                    + ") is out of stock. Quantity: 0.";

            ArrayList<String> parts =
                    smsManager.divideMessage(message);

            if (parts.size() == 1) {
                smsManager.sendTextMessage(
                        phoneNumber, null, message, null, null);
            } else {
                smsManager.sendMultipartTextMessage(
                        phoneNumber, null, parts, null, null);
            }

            // Submission does not confirm successful delivery.
            showMessage(appContext, "SMS alert submitted.");

        } catch (RuntimeException exception) {
            Log.e("SmsNotifier", "SMS request failed", exception);
            showMessage(appContext,
                    "Unable to request SMS. Inventory was still saved.");
        }
    }

    private static void showMessage(Context context, String message) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(
                        context, message, Toast.LENGTH_LONG).show());
    }
}