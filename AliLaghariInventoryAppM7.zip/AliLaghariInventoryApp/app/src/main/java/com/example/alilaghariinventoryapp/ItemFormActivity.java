package com.example.alilaghariinventoryapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ItemFormActivity extends AppCompatActivity {

    private EditText nameInput;
    private EditText skuInput;
    private EditText quantityInput;
    private Button saveButton;
    private long itemId;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_form);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.itemFormRoot), (view, windowInsets) -> {
                    Insets insets = windowInsets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                                    | WindowInsetsCompat.Type.ime());
                    view.setPadding(
                            insets.left, insets.top,
                            insets.right, insets.bottom);
                    return windowInsets;
                });

        nameInput = findViewById(R.id.itemNameInput);
        skuInput = findViewById(R.id.itemSkuInput);
        quantityInput = findViewById(R.id.itemQuantityInput);
        saveButton = findViewById(R.id.saveItemButton);

        // A valid item ID means we are editing a saved item.
        itemId = getIntent().getLongExtra("itemId", -1);

        findViewById(R.id.cancelItemButton)
                .setOnClickListener(view -> finish());
        saveButton.setOnClickListener(view -> saveItem());

        if (itemId != -1) {
            TextView title = findViewById(R.id.itemFormTitle);
            title.setText("Edit Item");
            loadItem();
        }
    }

    private void loadItem() {
        setBusy(true);

        databaseExecutor.execute(() -> {
            String name = null;
            String sku = null;
            int quantity = 0;

            try (DatabaseHelper database = new DatabaseHelper(this);
                 Cursor cursor = database.getItem(itemId)) {

                if (cursor.moveToFirst()) {
                    name = cursor.getString(1);
                    sku = cursor.getString(2);
                    quantity = cursor.getInt(3);
                }
            } catch (RuntimeException exception) {
                android.util.Log.e("ItemForm", "Item loading failed", exception);
            }

            final String savedName = name;
            final String savedSku = sku;
            final int savedQuantity = quantity;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setBusy(false);

                if (savedName == null) {
                    Toast.makeText(this,
                            "Unable to load this item.",
                            Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }

                nameInput.setText(savedName);
                skuInput.setText(savedSku);
                quantityInput.setText(String.valueOf(savedQuantity));
            });
        });
    }

    private void saveItem() {
        String name = nameInput.getText().toString().trim();
        String sku = skuInput.getText().toString().trim();
        String quantityText = quantityInput.getText().toString().trim();

        nameInput.setError(null);
        skuInput.setError(null);
        quantityInput.setError(null);

        if (name.isEmpty()) {
            nameInput.setError("Enter an item name.");
            nameInput.requestFocus();
            return;
        }

        if (sku.isEmpty()) {
            skuInput.setError("Enter a unique SKU.");
            skuInput.requestFocus();
            return;
        }

        final int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
            if (quantity < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException exception) {
            quantityInput.setError(
                    "Enter a whole number from 0 to 2147483647.");
            quantityInput.requestFocus();
            return;
        }

        setBusy(true);

        databaseExecutor.execute(() -> {
            String message;
            boolean success = false;
            boolean becameOutOfStock = false;

            try (DatabaseHelper database = new DatabaseHelper(this)) {
                if (itemId == -1) {
                    success = database.addItem(name, sku, quantity) != -1;
                } else {
                    int previousQuantity = -1;

                    try (android.database.Cursor cursor =
                                 database.getItem(itemId)) {
                        if (cursor.moveToFirst()) {
                            previousQuantity = cursor.getInt(3);
                        }
                    }

                    success = database.updateItem(
                            itemId, name, sku, quantity);

                    // Alert only when existing stock is reduced to zero.
                    becameOutOfStock = success
                            && previousQuantity > 0
                            && quantity == 0;
                }

                message = success
                        ? "Item saved."
                        : "Item not saved. Check that the SKU is unique.";
            } catch (RuntimeException exception) {
                message = "Unable to save the item. Please try again.";
                android.util.Log.e(
                        "ItemForm", "Item saving failed", exception);
            }

            final boolean saved = success;
            final String resultMessage = message;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setBusy(false);
                Toast.makeText(
                        this, resultMessage, Toast.LENGTH_LONG).show();

                if (saved) {
                    finish();
                }
            });

            // SMS failure does not undo the saved inventory change.
            if (becameOutOfStock) {
                SmsNotifier.sendOutOfStockAlert(
                        getApplicationContext(), name, sku);
            }
        });
    }

    private void setBusy(boolean busy) {
        saveButton.setEnabled(!busy);
        nameInput.setEnabled(!busy);
        skuInput.setEnabled(!busy);
        quantityInput.setEnabled(!busy);
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}